window.SMARTHUB_SITE_CONFIG = {
  // Required: Supabase project URL, e.g. https://abcd1234.supabase.co
  supabaseUrl: '',

  // Required: Supabase anon/public key (safe for client-side use)
  supabaseAnonKey: '',

  // Optional: email verification and password-reset redirect URL
  // Keep this path available in your static deployment.
  emailRedirectTo: `${window.location.origin}/email-confirmation/`,

  // Optional: display label used in status messages
  appName: 'SmartHub Portal',
};
