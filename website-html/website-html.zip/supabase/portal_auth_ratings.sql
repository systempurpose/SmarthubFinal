-- SmartHub website portal schema for static hosting (GitHub + Cloudflare Pages)
-- Features:
-- 1) Supabase auth profiles with role (user/admin)
-- 2) Admin-managed Windows download URL
-- 3) User ratings (one rating per account)
-- 4) Admin audit log for download URL changes

create table if not exists public.portal_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '',
  role text not null default 'user' check (role in ('user', 'admin')),
  created_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.portal_settings (
  setting_key text primary key,
  setting_value text not null,
  updated_by uuid references auth.users(id) on delete set null,
  updated_at timestamptz not null default timezone('utc', now())
);

insert into public.portal_settings (setting_key, setting_value)
values ('windows_download_url', 'https://github.com/systempurpose/SmartHub3/releases/latest')
on conflict (setting_key) do nothing;

create table if not exists public.portal_ratings (
  user_id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'User',
  stars smallint not null check (stars between 1 and 5),
  comment text not null default '',
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.portal_download_audit (
  id bigint generated always as identity primary key,
  changed_by uuid references auth.users(id) on delete set null,
  changed_by_display text not null default '',
  previous_url text not null default '',
  new_url text not null default '',
  changed_at timestamptz not null default timezone('utc', now())
);

create index if not exists portal_download_audit_changed_at_idx
on public.portal_download_audit (changed_at desc);

create or replace function public.portal_is_admin(check_user_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.portal_profiles p
    where p.user_id = check_user_id
      and p.role = 'admin'
  );
$$;

grant execute on function public.portal_is_admin(uuid) to anon, authenticated;

alter table public.portal_profiles enable row level security;
alter table public.portal_settings enable row level security;
alter table public.portal_ratings enable row level security;
alter table public.portal_download_audit enable row level security;

drop policy if exists portal_profiles_select_own on public.portal_profiles;
create policy portal_profiles_select_own
on public.portal_profiles
for select
to authenticated
using (auth.uid() = user_id);

drop policy if exists portal_profiles_insert_own on public.portal_profiles;
create policy portal_profiles_insert_own
on public.portal_profiles
for insert
to authenticated
with check (auth.uid() = user_id);

drop policy if exists portal_settings_public_read on public.portal_settings;
create policy portal_settings_public_read
on public.portal_settings
for select
to anon, authenticated
using (true);

drop policy if exists portal_settings_admin_insert on public.portal_settings;
create policy portal_settings_admin_insert
on public.portal_settings
for insert
to authenticated
with check (public.portal_is_admin(auth.uid()));

drop policy if exists portal_settings_admin_update on public.portal_settings;
create policy portal_settings_admin_update
on public.portal_settings
for update
to authenticated
using (public.portal_is_admin(auth.uid()))
with check (public.portal_is_admin(auth.uid()));

drop policy if exists portal_ratings_public_read on public.portal_ratings;
create policy portal_ratings_public_read
on public.portal_ratings
for select
to anon, authenticated
using (true);

drop policy if exists portal_ratings_insert_own on public.portal_ratings;
create policy portal_ratings_insert_own
on public.portal_ratings
for insert
to authenticated
with check (auth.uid() = user_id);

drop policy if exists portal_ratings_update_own on public.portal_ratings;
create policy portal_ratings_update_own
on public.portal_ratings
for update
to authenticated
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

drop policy if exists portal_download_audit_admin_read on public.portal_download_audit;
create policy portal_download_audit_admin_read
on public.portal_download_audit
for select
to authenticated
using (public.portal_is_admin(auth.uid()));

drop policy if exists portal_download_audit_admin_insert on public.portal_download_audit;
create policy portal_download_audit_admin_insert
on public.portal_download_audit
for insert
to authenticated
with check (
  public.portal_is_admin(auth.uid())
  and changed_by = auth.uid()
);

grant usage on schema public to anon, authenticated;
grant select, insert on table public.portal_profiles to authenticated;
grant select on table public.portal_settings to anon, authenticated;
grant insert, update on table public.portal_settings to authenticated;
grant select on table public.portal_ratings to anon, authenticated;
grant insert, update on table public.portal_ratings to authenticated;
grant select, insert on table public.portal_download_audit to authenticated;

-- Promote your first admin manually in Supabase SQL editor after account signup:
-- update public.portal_profiles
-- set role = 'admin'
-- where user_id = 'YOUR_AUTH_USER_UUID';
