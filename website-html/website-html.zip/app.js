const RELEASE_OWNER = 'systempurpose';
const RELEASE_REPO = 'SmartHub3';

const RELEASE_FALLBACK_URL = `https://github.com/${RELEASE_OWNER}/${RELEASE_REPO}/releases/latest`;
const RELEASE_API_URL = `https://api.github.com/repos/${RELEASE_OWNER}/${RELEASE_REPO}/releases/latest`;

const TRACKING_NAMESPACE = 'smarthub3-portal';
const TRACKING_KEY = 'windows-download-clicks';

const PORTAL_PROFILE_TABLE = 'portal_profiles';
const PORTAL_SETTINGS_TABLE = 'portal_settings';
const PORTAL_RATINGS_TABLE = 'portal_ratings';
const PORTAL_DOWNLOAD_AUDIT_TABLE = 'portal_download_audit';
const WINDOWS_DOWNLOAD_SETTING_KEY = 'windows_download_url';

const DEFAULT_SITE_CONFIG = Object.freeze({
  supabaseUrl: '',
  supabaseAnonKey: '',
  emailRedirectTo: '',
  appName: 'SmartHub Portal',
});

const els = {
  downloadBtn: document.getElementById('downloadBtn'),
  downloadStatus: document.getElementById('downloadStatus'),
  downloadSource: document.getElementById('downloadSource'),
  metricVersion: document.getElementById('metricVersion'),
  metricGithubDownloads: document.getElementById('metricGithubDownloads'),
  metricTrackedClicks: document.getElementById('metricTrackedClicks'),
  metricPublishedAt: document.getElementById('metricPublishedAt'),
  siteUrl: document.getElementById('siteUrl'),

  navUserBadge: document.getElementById('navUserBadge'),
  navAdminBadge: document.getElementById('navAdminBadge'),
  navLogoutBtn: document.getElementById('navLogoutBtn'),

  authNameField: document.getElementById('authNameField'),
  authDisplayName: document.getElementById('authDisplayName'),
  authEmail: document.getElementById('authEmail'),
  authPassword: document.getElementById('authPassword'),
  authConfirmField: document.getElementById('authConfirmField'),
  authConfirmPassword: document.getElementById('authConfirmPassword'),
  authPrimaryBtn: document.getElementById('authPrimaryBtn'),
  authSwitchBtn: document.getElementById('authSwitchBtn'),
  authForgotBtn: document.getElementById('authForgotBtn'),
  authStatus: document.getElementById('authStatus'),
  authConfigStatus: document.getElementById('authConfigStatus'),

  adminCard: document.getElementById('adminCard'),
  adminDownloadUrl: document.getElementById('adminDownloadUrl'),
  adminSaveBtn: document.getElementById('adminSaveBtn'),
  adminResetBtn: document.getElementById('adminResetBtn'),
  adminStatus: document.getElementById('adminStatus'),
  adminAuditRefreshBtn: document.getElementById('adminAuditRefreshBtn'),
  adminAuditStatus: document.getElementById('adminAuditStatus'),
  adminAuditBody: document.getElementById('adminAuditBody'),

  ratingAverage: document.getElementById('ratingAverage'),
  ratingCount: document.getElementById('ratingCount'),
  ratingStars: document.getElementById('ratingStars'),
  ratingComment: document.getElementById('ratingComment'),
  ratingSubmitBtn: document.getElementById('ratingSubmitBtn'),
  ratingStatus: document.getElementById('ratingStatus'),
  ratingList: document.getElementById('ratingList'),
};

let releaseDerivedDownloadUrl = RELEASE_FALLBACK_URL;
let managedDownloadUrl = '';
let resolvedDownloadUrl = RELEASE_FALLBACK_URL;

let supabaseClient = null;
let currentUser = null;
let currentProfile = null;
let authMode = 'login';
let authSyncToken = 0;

function cleanText(value) {
  return String(value == null ? '' : value).trim();
}

function setVisible(el, visible) {
  if (!el) return;
  el.classList.toggle('hidden', !visible);
}

function setDownloadStatus(message, kind) {
  if (!els.downloadStatus) return;
  els.downloadStatus.textContent = cleanText(message);
  els.downloadStatus.classList.remove('ok', 'error', 'muted');
  if (kind === 'ok') els.downloadStatus.classList.add('ok');
  if (kind === 'error') els.downloadStatus.classList.add('error');
  if (kind === 'muted') els.downloadStatus.classList.add('muted');
}

function setUiStatus(el, message, kind) {
  if (!el) return;
  el.textContent = cleanText(message);
  el.classList.remove('ok', 'error', 'muted');
  if (kind === 'ok') el.classList.add('ok');
  if (kind === 'error') el.classList.add('error');
  if (kind === 'muted') el.classList.add('muted');
}

function setPortalNote(el, message, kind) {
  if (!el) return;
  const text = cleanText(message);
  el.textContent = text;
  el.classList.remove('error', 'ok', 'hidden');
  if (kind === 'error') el.classList.add('error');
  if (kind === 'ok') el.classList.add('ok');
  if (!text) {
    el.classList.add('hidden');
  }
}

function setButtonBusy(button, isBusy, busyLabel, readyLabel) {
  if (!button) return;
  button.disabled = !!isBusy;
  if (isBusy && busyLabel) {
    button.dataset.prevText = button.textContent || '';
    button.textContent = busyLabel;
    return;
  }
  if (!isBusy) {
    if (readyLabel) {
      button.textContent = readyLabel;
      return;
    }
    if (button.dataset.prevText) {
      button.textContent = button.dataset.prevText;
      delete button.dataset.prevText;
    }
  }
}

function formatNumber(value) {
  const num = Number(value);
  if (!Number.isFinite(num)) return '--';
  return new Intl.NumberFormat().format(num);
}

function formatDate(isoText) {
  const value = cleanText(isoText);
  if (!value) return '--';
  const dt = new Date(value);
  if (Number.isNaN(dt.getTime())) return '--';
  return new Intl.DateTimeFormat(undefined, {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  }).format(dt);
}

function formatDateTime(isoText) {
  const value = cleanText(isoText);
  if (!value) return '--';
  const dt = new Date(value);
  if (Number.isNaN(dt.getTime())) return '--';
  return new Intl.DateTimeFormat(undefined, {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(dt);
}

function compactUrl(value, maxLen = 52) {
  const text = cleanText(value);
  if (!text) return '';
  if (text.length <= maxLen) return text;
  return `${text.slice(0, maxLen - 3)}...`;
}

function compactId(value) {
  const text = cleanText(value);
  if (!text) return '';
  if (text.length <= 12) return text;
  return `${text.slice(0, 8)}...`;
}

function isHttpUrl(url) {
  const value = cleanText(url);
  if (!value) return false;
  try {
    const parsed = new URL(value);
    return parsed.protocol === 'http:' || parsed.protocol === 'https:';
  } catch {
    return false;
  }
}

function defaultEmailRedirectUrl() {
  return `${window.location.origin}/email-confirmation/`;
}

function resolveSiteConfig() {
  const raw = window.SMARTHUB_SITE_CONFIG && typeof window.SMARTHUB_SITE_CONFIG === 'object'
    ? window.SMARTHUB_SITE_CONFIG
    : {};

  const cfg = {
    supabaseUrl: cleanText(raw.supabaseUrl || raw.SMARTHUB_SUPABASE_URL || DEFAULT_SITE_CONFIG.supabaseUrl),
    supabaseAnonKey: cleanText(raw.supabaseAnonKey || raw.SMARTHUB_SUPABASE_ANON_KEY || DEFAULT_SITE_CONFIG.supabaseAnonKey),
    emailRedirectTo: cleanText(raw.emailRedirectTo || raw.SMARTHUB_SUPABASE_EMAIL_REDIRECT_URL || DEFAULT_SITE_CONFIG.emailRedirectTo),
    appName: cleanText(raw.appName || raw.APP_NAME || DEFAULT_SITE_CONFIG.appName),
  };

  if (!cfg.emailRedirectTo) {
    cfg.emailRedirectTo = defaultEmailRedirectUrl();
  }

  return cfg;
}

const siteConfig = resolveSiteConfig();

function canUseSupabase() {
  return !!(siteConfig.supabaseUrl && siteConfig.supabaseAnonKey);
}

function initSupabaseClient() {
  if (!canUseSupabase()) return null;

  if (!window.supabase || typeof window.supabase.createClient !== 'function') {
    return null;
  }

  try {
    return window.supabase.createClient(siteConfig.supabaseUrl, siteConfig.supabaseAnonKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
        detectSessionInUrl: true,
      },
    });
  } catch {
    return null;
  }
}

function pickWindowsAsset(assets) {
  if (!Array.isArray(assets) || !assets.length) return null;

  const scored = assets
    .filter(asset => asset && typeof asset.browser_download_url === 'string')
    .map((asset) => {
      const name = cleanText(asset.name).toLowerCase();
      let score = 0;

      if (name.endsWith('.exe')) score += 100;
      if (name.endsWith('.msi')) score += 90;
      if (name.endsWith('.zip')) score += 60;
      if (name.includes('win') || name.includes('windows') || name.includes('setup') || name.includes('installer')) {
        score += 30;
      }

      return { asset, score };
    })
    .sort((a, b) => b.score - a.score);

  return scored.length ? scored[0].asset : null;
}

function refreshResolvedDownloadUrl() {
  if (isHttpUrl(managedDownloadUrl)) {
    resolvedDownloadUrl = managedDownloadUrl;
  } else if (isHttpUrl(releaseDerivedDownloadUrl)) {
    resolvedDownloadUrl = releaseDerivedDownloadUrl;
  } else {
    resolvedDownloadUrl = RELEASE_FALLBACK_URL;
  }

  if (!els.downloadSource) return;
  if (isHttpUrl(managedDownloadUrl)) {
    els.downloadSource.textContent = 'Download source: admin-managed Supabase URL.';
    return;
  }
  els.downloadSource.textContent = 'Download source: auto GitHub latest release.';
}

async function loadReleaseMetrics() {
  try {
    const res = await fetch(RELEASE_API_URL, {
      headers: { Accept: 'application/vnd.github+json' },
      cache: 'no-store',
    });

    if (!res.ok) {
      throw new Error(`Release API HTTP ${res.status}`);
    }

    const release = await res.json();
    const tag = cleanText(release && release.tag_name) || 'latest';
    const publishedAt = cleanText(release && release.published_at);

    const assets = Array.isArray(release && release.assets) ? release.assets : [];
    const selectedAsset = pickWindowsAsset(assets);

    if (selectedAsset && typeof selectedAsset.browser_download_url === 'string') {
      releaseDerivedDownloadUrl = selectedAsset.browser_download_url;
    } else if (release && typeof release.html_url === 'string') {
      releaseDerivedDownloadUrl = release.html_url;
    } else {
      releaseDerivedDownloadUrl = RELEASE_FALLBACK_URL;
    }

    const githubDownloads = assets.reduce((sum, asset) => {
      const count = Number(asset && asset.download_count);
      return sum + (Number.isFinite(count) ? count : 0);
    }, 0);

    if (els.metricVersion) els.metricVersion.textContent = tag;
    if (els.metricPublishedAt) els.metricPublishedAt.textContent = formatDate(publishedAt);
    if (els.metricGithubDownloads) els.metricGithubDownloads.textContent = formatNumber(githubDownloads);

    refreshResolvedDownloadUrl();
    setDownloadStatus('Ready. Download button tracks clicks and redirects to the selected Windows app URL.', 'ok');
  } catch {
    if (els.metricVersion) els.metricVersion.textContent = 'latest';
    if (els.metricPublishedAt) els.metricPublishedAt.textContent = '--';
    if (els.metricGithubDownloads) els.metricGithubDownloads.textContent = '--';

    releaseDerivedDownloadUrl = RELEASE_FALLBACK_URL;
    refreshResolvedDownloadUrl();
    setDownloadStatus('Release API is unavailable right now. Download opens the latest release page.', 'muted');
  }
}

async function loadTrackedClicks() {
  try {
    const url = `https://api.countapi.xyz/get/${encodeURIComponent(TRACKING_NAMESPACE)}/${encodeURIComponent(TRACKING_KEY)}`;
    const res = await fetch(url, { cache: 'no-store' });
    if (!res.ok) throw new Error('Tracking API unavailable');

    const data = await res.json();
    const count = Number(data && data.value);
    if (els.metricTrackedClicks) {
      els.metricTrackedClicks.textContent = formatNumber(Number.isFinite(count) ? count : 0);
    }
  } catch {
    if (els.metricTrackedClicks) {
      els.metricTrackedClicks.textContent = '--';
    }
  }
}

async function incrementTrackedClicks() {
  try {
    const url = `https://api.countapi.xyz/hit/${encodeURIComponent(TRACKING_NAMESPACE)}/${encodeURIComponent(TRACKING_KEY)}`;
    const res = await fetch(url, { cache: 'no-store' });
    if (!res.ok) throw new Error('Tracking increment failed');

    const data = await res.json();
    const count = Number(data && data.value);
    if (els.metricTrackedClicks && Number.isFinite(count)) {
      els.metricTrackedClicks.textContent = formatNumber(count);
    }
  } catch {
    // best-effort tracking only
  }
}

function setSiteUrl() {
  if (!els.siteUrl) return;
  els.siteUrl.textContent = `${window.location.origin}/`;
}

function deriveDisplayNameFromUser(user) {
  if (!user || typeof user !== 'object') return 'User';

  const metadata = user.user_metadata && typeof user.user_metadata === 'object'
    ? user.user_metadata
    : {};

  const fromMetadata = cleanText(metadata.display_name || metadata.full_name || metadata.name);
  if (fromMetadata) return fromMetadata;

  const fromEmail = cleanText(user.email);
  if (!fromEmail) return 'User';
  return fromEmail.split('@')[0] || fromEmail;
}

function renderAuthMode() {
  const isRegister = authMode === 'register';

  setVisible(els.authNameField, isRegister);
  setVisible(els.authConfirmField, isRegister);

  if (els.authPrimaryBtn) {
    els.authPrimaryBtn.textContent = isRegister ? 'Create account' : 'Sign in';
  }

  if (els.authSwitchBtn) {
    els.authSwitchBtn.textContent = isRegister
      ? 'Already have an account? Sign in'
      : 'Need an account? Register';
  }

  setVisible(els.authForgotBtn, !isRegister);
}

function renderSessionUi() {
  const signedIn = !!currentUser;
  const isAdmin = !!(currentProfile && currentProfile.role === 'admin');
  const navLabel = signedIn
    ? cleanText((currentProfile && currentProfile.display_name) || deriveDisplayNameFromUser(currentUser) || currentUser.email)
    : 'Guest';

  if (els.navUserBadge) {
    els.navUserBadge.textContent = navLabel;
    els.navUserBadge.title = signedIn && currentUser && currentUser.email
      ? String(currentUser.email)
      : 'Not signed in';
  }

  setVisible(els.navAdminBadge, signedIn && isAdmin);
  setVisible(els.navLogoutBtn, signedIn);
  setVisible(els.adminCard, signedIn && isAdmin);

  if (els.ratingSubmitBtn) {
    els.ratingSubmitBtn.disabled = !signedIn || !supabaseClient;
  }

  if (!signedIn) {
    setUiStatus(els.authStatus, 'Not signed in.', 'muted');
    setUiStatus(els.ratingStatus, supabaseClient ? 'Sign in to post your rating.' : 'Supabase is not configured yet.', 'muted');
    return;
  }

  setUiStatus(els.authStatus, `Signed in as ${navLabel}.`, 'ok');
}

async function ensureOwnProfile(user, requestedName) {
  if (!supabaseClient || !user || !user.id) return null;

  const { data: existing, error: selectError } = await supabaseClient
    .from(PORTAL_PROFILE_TABLE)
    .select('user_id, display_name, role')
    .eq('user_id', user.id)
    .maybeSingle();

  if (existing && !selectError) {
    return existing;
  }

  const name = cleanText(requestedName) || deriveDisplayNameFromUser(user);
  const payload = {
    user_id: user.id,
    display_name: name,
  };

  const { error: insertError } = await supabaseClient
    .from(PORTAL_PROFILE_TABLE)
    .insert(payload);

  if (insertError && !/duplicate/i.test(cleanText(insertError.message))) {
    throw insertError;
  }

  const { data: created } = await supabaseClient
    .from(PORTAL_PROFILE_TABLE)
    .select('user_id, display_name, role')
    .eq('user_id', user.id)
    .maybeSingle();

  return created || {
    user_id: user.id,
    display_name: name,
    role: 'user',
  };
}

async function loadManagedDownloadSetting() {
  if (!supabaseClient) {
    managedDownloadUrl = '';
    refreshResolvedDownloadUrl();
    return;
  }

  const { data, error } = await supabaseClient
    .from(PORTAL_SETTINGS_TABLE)
    .select('setting_value')
    .eq('setting_key', WINDOWS_DOWNLOAD_SETTING_KEY)
    .maybeSingle();

  if (error) {
    managedDownloadUrl = '';
    refreshResolvedDownloadUrl();
    return;
  }

  const value = cleanText(data && data.setting_value);
  managedDownloadUrl = isHttpUrl(value) ? value : '';

  if (els.adminDownloadUrl) {
    els.adminDownloadUrl.value = managedDownloadUrl;
  }

  refreshResolvedDownloadUrl();
}

function setAdminAuditPlaceholder(message) {
  if (!els.adminAuditBody) return;
  const text = cleanText(message) || 'No admin changes yet.';
  els.adminAuditBody.innerHTML = `<tr><td colspan="4">${escapeHtml(text)}</td></tr>`;
}

function renderAdminAuditRows(rows) {
  if (!els.adminAuditBody) return;

  const safeRows = Array.isArray(rows) ? rows : [];
  if (!safeRows.length) {
    setAdminAuditPlaceholder('No admin changes yet.');
    return;
  }

  const html = safeRows.map((row) => {
    const actorLabel = cleanText(row.changed_by_display) || 'Admin';
    const actorId = compactId(row.changed_by);
    const previousUrl = cleanText(row.previous_url);
    const newUrl = cleanText(row.new_url);
    const whenText = formatDateTime(row.changed_at);

    const previousCell = isHttpUrl(previousUrl)
      ? `<a class="audit-link" href="${escapeHtml(previousUrl)}" target="_blank" rel="noopener noreferrer">${escapeHtml(compactUrl(previousUrl))}</a>`
      : '<span class="audit-empty">Auto mode / none</span>';

    const newCell = isHttpUrl(newUrl)
      ? `<a class="audit-link" href="${escapeHtml(newUrl)}" target="_blank" rel="noopener noreferrer">${escapeHtml(compactUrl(newUrl))}</a>`
      : '<span class="audit-empty">Auto mode (GitHub latest)</span>';

    return [
      '<tr>',
      '<td>',
      `<span class="audit-actor">${escapeHtml(actorLabel)}</span>`,
      actorId ? `<span class="audit-actor-id">${escapeHtml(actorId)}</span>` : '',
      '</td>',
      `<td>${previousCell}</td>`,
      `<td>${newCell}</td>`,
      `<td>${escapeHtml(whenText)}</td>`,
      '</tr>',
    ].join('');
  }).join('');

  els.adminAuditBody.innerHTML = html;
}

async function loadAdminAuditLog() {
  if (!supabaseClient || !currentUser || !currentProfile || currentProfile.role !== 'admin') {
    setAdminAuditPlaceholder('Admin audit log appears after admin sign-in.');
    setUiStatus(els.adminAuditStatus, 'Audit log is available only for admins.', 'muted');
    return;
  }

  const { data, error } = await supabaseClient
    .from(PORTAL_DOWNLOAD_AUDIT_TABLE)
    .select('changed_by, changed_by_display, previous_url, new_url, changed_at')
    .order('changed_at', { ascending: false })
    .limit(20);

  if (error) {
    setAdminAuditPlaceholder('Could not load audit history.');
    setUiStatus(
      els.adminAuditStatus,
      `Audit log unavailable: ${cleanText(error.message) || 'unknown error'}`,
      'error',
    );
    return;
  }

  const rows = Array.isArray(data) ? data : [];
  renderAdminAuditRows(rows);

  setUiStatus(
    els.adminAuditStatus,
    rows.length
      ? `Showing ${rows.length} most recent change${rows.length > 1 ? 's' : ''}.`
      : 'No admin changes yet.',
    rows.length ? 'ok' : 'muted',
  );
}

function renderRatings(rows) {
  if (!els.ratingList) return;

  const safeRows = Array.isArray(rows) ? rows : [];
  if (!safeRows.length) {
    els.ratingList.innerHTML = '<div class="rating-item">No ratings yet. Be the first to rate SmartHub.</div>';
    return;
  }

  const cards = safeRows.slice(0, 8).map((row) => {
    const displayName = cleanText(row.display_name) || 'User';
    const stars = Number(row.stars);
    const starText = Number.isFinite(stars) ? `${stars}/5` : '--';
    const dateText = formatDate(row.updated_at || row.created_at);
    const comment = cleanText(row.comment);

    return [
      '<div class="rating-item">',
      '<div class="rating-head">',
      `<span class="rating-user">${escapeHtml(displayName)}</span>`,
      `<span class="rating-stars">${escapeHtml(starText)}</span>`,
      '</div>',
      `<div class="rating-head"><span>${escapeHtml(dateText)}</span></div>`,
      comment ? `<div class="rating-comment">${escapeHtml(comment)}</div>` : '',
      '</div>',
    ].join('');
  });

  els.ratingList.innerHTML = cards.join('');
}

function escapeHtml(value) {
  return String(value == null ? '' : value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

async function loadRatings() {
  if (!supabaseClient) {
    if (els.ratingAverage) els.ratingAverage.textContent = '--';
    if (els.ratingCount) els.ratingCount.textContent = '0';
    renderRatings([]);
    return;
  }

  const { data, error } = await supabaseClient
    .from(PORTAL_RATINGS_TABLE)
    .select('user_id, display_name, stars, comment, created_at, updated_at')
    .order('updated_at', { ascending: false })
    .limit(100);

  if (error) {
    if (els.ratingAverage) els.ratingAverage.textContent = '--';
    if (els.ratingCount) els.ratingCount.textContent = '0';
    renderRatings([]);
    setUiStatus(els.ratingStatus, `Could not load ratings: ${cleanText(error.message) || 'unknown error'}`, 'error');
    return;
  }

  const rows = Array.isArray(data) ? data : [];
  const count = rows.length;
  const sum = rows.reduce((total, row) => total + (Number.isFinite(Number(row.stars)) ? Number(row.stars) : 0), 0);
  const average = count > 0 ? (sum / count).toFixed(1) : '--';

  if (els.ratingAverage) els.ratingAverage.textContent = String(average);
  if (els.ratingCount) els.ratingCount.textContent = formatNumber(count);

  renderRatings(rows);

  if (currentUser) {
    setUiStatus(els.ratingStatus, 'You can update your rating anytime.', 'ok');
  }
}

async function loadMyRating() {
  if (!supabaseClient || !currentUser || !currentUser.id) {
    if (els.ratingStars) els.ratingStars.value = '5';
    if (els.ratingComment) els.ratingComment.value = '';
    return;
  }

  const { data, error } = await supabaseClient
    .from(PORTAL_RATINGS_TABLE)
    .select('stars, comment')
    .eq('user_id', currentUser.id)
    .maybeSingle();

  if (error || !data) {
    if (els.ratingStars) els.ratingStars.value = '5';
    if (els.ratingComment) els.ratingComment.value = '';
    return;
  }

  if (els.ratingStars && Number.isFinite(Number(data.stars))) {
    els.ratingStars.value = String(data.stars);
  }
  if (els.ratingComment) {
    els.ratingComment.value = cleanText(data.comment);
  }
}

async function syncSessionFromSupabase(session) {
  const runToken = ++authSyncToken;
  currentUser = session && session.user ? session.user : null;
  currentProfile = null;

  if (currentUser) {
    try {
      currentProfile = await ensureOwnProfile(currentUser);
    } catch (e) {
      const msg = e && e.message ? String(e.message) : 'profile sync failed';
      setUiStatus(els.authStatus, `Signed in, but profile sync failed: ${msg}`, 'error');
    }
  }

  if (runToken !== authSyncToken) return;

  renderSessionUi();
  await loadManagedDownloadSetting();
  await loadRatings();
  await loadMyRating();
  await loadAdminAuditLog();
}

async function handleRegister() {
  if (!supabaseClient) return;

  const displayName = cleanText(els.authDisplayName && els.authDisplayName.value);
  const email = cleanText(els.authEmail && els.authEmail.value);
  const password = cleanText(els.authPassword && els.authPassword.value);
  const confirmPassword = cleanText(els.authConfirmPassword && els.authConfirmPassword.value);

  if (displayName.length < 2) {
    setUiStatus(els.authStatus, 'Display name must be at least 2 characters.', 'error');
    return;
  }
  if (!email || !password) {
    setUiStatus(els.authStatus, 'Enter email and password.', 'error');
    return;
  }
  if (password.length < 8) {
    setUiStatus(els.authStatus, 'Password must be at least 8 characters.', 'error');
    return;
  }
  if (password !== confirmPassword) {
    setUiStatus(els.authStatus, 'Password confirmation does not match.', 'error');
    return;
  }

  setButtonBusy(els.authPrimaryBtn, true, 'Creating account...');
  setUiStatus(els.authStatus, 'Creating account...', 'muted');

  try {
    const { data, error } = await supabaseClient.auth.signUp({
      email,
      password,
      options: {
        data: {
          display_name: displayName,
          full_name: displayName,
        },
        emailRedirectTo: siteConfig.emailRedirectTo || defaultEmailRedirectUrl(),
      },
    });

    if (error) {
      throw error;
    }

    if (data && data.session) {
      if (data.user) {
        await ensureOwnProfile(data.user, displayName);
      }
      currentUser = data.user;
      await syncSessionFromSupabase(data.session);
      setUiStatus(els.authStatus, 'Account created and signed in.', 'ok');
      if (els.authPassword) els.authPassword.value = '';
      if (els.authConfirmPassword) els.authConfirmPassword.value = '';
      return;
    }

    setUiStatus(
      els.authStatus,
      'Account created. Check your email for verification, then sign in.',
      'ok',
    );
    authMode = 'login';
    renderAuthMode();
  } catch (e) {
    const msg = e && e.message ? String(e.message) : 'Registration failed.';
    setUiStatus(els.authStatus, msg, 'error');
  } finally {
    setButtonBusy(els.authPrimaryBtn, false);
  }
}

async function handleLogin() {
  if (!supabaseClient) return;

  const email = cleanText(els.authEmail && els.authEmail.value);
  const password = cleanText(els.authPassword && els.authPassword.value);

  if (!email || !password) {
    setUiStatus(els.authStatus, 'Enter email and password.', 'error');
    return;
  }

  setButtonBusy(els.authPrimaryBtn, true, 'Signing in...');
  setUiStatus(els.authStatus, 'Signing in...', 'muted');

  try {
    const { data, error } = await supabaseClient.auth.signInWithPassword({
      email,
      password,
    });

    if (error || !data || !data.session) {
      throw error || new Error('Invalid login session.');
    }

    await syncSessionFromSupabase(data.session);
    if (els.authPassword) els.authPassword.value = '';
    if (els.authConfirmPassword) els.authConfirmPassword.value = '';

    setUiStatus(els.authStatus, 'Sign-in successful.', 'ok');
  } catch (e) {
    const msg = e && e.message ? String(e.message) : 'Login failed.';
    setUiStatus(els.authStatus, msg, 'error');
  } finally {
    setButtonBusy(els.authPrimaryBtn, false);
  }
}

async function handleForgotPassword() {
  if (!supabaseClient) return;

  const email = cleanText(els.authEmail && els.authEmail.value);
  if (!email) {
    setUiStatus(els.authStatus, 'Enter your email first.', 'error');
    return;
  }

  setUiStatus(els.authStatus, 'Sending password reset email...', 'muted');

  const { error } = await supabaseClient.auth.resetPasswordForEmail(email, {
    redirectTo: siteConfig.emailRedirectTo || defaultEmailRedirectUrl(),
  });

  if (error) {
    setUiStatus(els.authStatus, error.message || 'Could not send reset email.', 'error');
    return;
  }

  setUiStatus(els.authStatus, 'Password reset email sent. Check your inbox.', 'ok');
}

async function handleLogout() {
  if (!supabaseClient) return;

  try {
    await supabaseClient.auth.signOut();
  } catch {
    // ignore
  }

  currentUser = null;
  currentProfile = null;
  renderSessionUi();
  await loadManagedDownloadSetting();
  await loadRatings();
  await loadMyRating();
  await loadAdminAuditLog();
}

async function handleAuthPrimary() {
  if (!supabaseClient) {
    setUiStatus(els.authStatus, 'Supabase config missing. Edit site-config.js first.', 'error');
    return;
  }

  if (authMode === 'register') {
    await handleRegister();
    return;
  }
  await handleLogin();
}

function handleAuthSwitch() {
  authMode = authMode === 'register' ? 'login' : 'register';
  renderAuthMode();
  setUiStatus(
    els.authStatus,
    authMode === 'register' ? 'Fill in details to create your account.' : 'Sign in with your account.',
    'muted',
  );
}

async function handleAdminSave(customUrl) {
  if (!supabaseClient || !currentUser || !currentProfile || currentProfile.role !== 'admin') {
    setUiStatus(els.adminStatus, 'Admin session is required.', 'error');
    return;
  }

  const value = cleanText(customUrl);
  if (value && !isHttpUrl(value)) {
    setUiStatus(els.adminStatus, 'Please enter a valid http/https URL.', 'error');
    return;
  }

  const previousValue = cleanText(managedDownloadUrl);
  if (value === previousValue) {
    setUiStatus(els.adminStatus, 'No change detected. The download URL is already up to date.', 'muted');
    await loadAdminAuditLog();
    return;
  }

  setButtonBusy(els.adminSaveBtn, true, 'Saving...');

  try {
    const nowIso = new Date().toISOString();
    const payload = {
      setting_key: WINDOWS_DOWNLOAD_SETTING_KEY,
      setting_value: value,
      updated_by: currentUser.id,
      updated_at: nowIso,
    };

    const { error } = await supabaseClient
      .from(PORTAL_SETTINGS_TABLE)
      .upsert(payload, { onConflict: 'setting_key' });

    if (error) {
      throw error;
    }

    managedDownloadUrl = value;
    refreshResolvedDownloadUrl();

    const actorName = cleanText((currentProfile && currentProfile.display_name) || deriveDisplayNameFromUser(currentUser));
    const auditPayload = {
      changed_by: currentUser.id,
      changed_by_display: actorName,
      previous_url: previousValue,
      new_url: value,
      changed_at: nowIso,
    };

    const { error: auditError } = await supabaseClient
      .from(PORTAL_DOWNLOAD_AUDIT_TABLE)
      .insert(auditPayload);

    await loadAdminAuditLog();

    if (auditError) {
      setUiStatus(
        els.adminStatus,
        `Download URL saved, but audit log insert failed: ${cleanText(auditError.message) || 'unknown error'}`,
        'error',
      );
      return;
    }

    setUiStatus(
      els.adminStatus,
      value
        ? 'Download URL saved. Users now download from the admin-managed URL.'
        : 'Admin URL cleared. Portal is now using GitHub auto mode.',
      'ok',
    );
  } catch (e) {
    const msg = e && e.message ? String(e.message) : 'Could not save download URL.';
    setUiStatus(els.adminStatus, msg, 'error');
  } finally {
    setButtonBusy(els.adminSaveBtn, false);
  }
}

async function handleRatingSubmit() {
  if (!supabaseClient || !currentUser) {
    setUiStatus(els.ratingStatus, 'Sign in first before posting your rating.', 'error');
    return;
  }

  const stars = Number.parseInt(cleanText(els.ratingStars && els.ratingStars.value), 10);
  const comment = cleanText(els.ratingComment && els.ratingComment.value).slice(0, 500);

  if (!Number.isFinite(stars) || stars < 1 || stars > 5) {
    setUiStatus(els.ratingStatus, 'Select a rating between 1 and 5 stars.', 'error');
    return;
  }

  if (comment.length > 500) {
    setUiStatus(els.ratingStatus, 'Comment must be 500 characters or less.', 'error');
    return;
  }

  setButtonBusy(els.ratingSubmitBtn, true, 'Saving...');
  setUiStatus(els.ratingStatus, 'Saving your rating...', 'muted');

  try {
    const payload = {
      user_id: currentUser.id,
      display_name: cleanText((currentProfile && currentProfile.display_name) || deriveDisplayNameFromUser(currentUser)),
      stars,
      comment,
      updated_at: new Date().toISOString(),
    };

    const { error } = await supabaseClient
      .from(PORTAL_RATINGS_TABLE)
      .upsert(payload, { onConflict: 'user_id' });

    if (error) {
      throw error;
    }

    setUiStatus(els.ratingStatus, 'Your rating has been saved.', 'ok');
    await loadRatings();
  } catch (e) {
    const msg = e && e.message ? String(e.message) : 'Could not save rating.';
    setUiStatus(els.ratingStatus, msg, 'error');
  } finally {
    setButtonBusy(els.ratingSubmitBtn, false);
  }
}

async function onDownloadClick() {
  if (!els.downloadBtn) return;

  els.downloadBtn.disabled = true;
  setDownloadStatus('Preparing secure redirect to Windows download...', 'muted');

  try {
    await incrementTrackedClicks();
  } finally {
    window.location.href = resolvedDownloadUrl;
  }
}

function bindEvents() {
  if (els.downloadBtn) {
    els.downloadBtn.addEventListener('click', onDownloadClick);
  }

  if (els.authPrimaryBtn) {
    els.authPrimaryBtn.addEventListener('click', () => {
      void handleAuthPrimary();
    });
  }

  if (els.authSwitchBtn) {
    els.authSwitchBtn.addEventListener('click', handleAuthSwitch);
  }

  if (els.authForgotBtn) {
    els.authForgotBtn.addEventListener('click', () => {
      void handleForgotPassword();
    });
  }

  if (els.navLogoutBtn) {
    els.navLogoutBtn.addEventListener('click', () => {
      void handleLogout();
    });
  }

  if (els.adminSaveBtn) {
    els.adminSaveBtn.addEventListener('click', () => {
      void handleAdminSave(els.adminDownloadUrl ? els.adminDownloadUrl.value : '');
    });
  }

  if (els.adminResetBtn) {
    els.adminResetBtn.addEventListener('click', () => {
      if (els.adminDownloadUrl) {
        els.adminDownloadUrl.value = '';
      }
      void handleAdminSave('');
    });
  }

  if (els.adminAuditRefreshBtn) {
    els.adminAuditRefreshBtn.addEventListener('click', () => {
      void loadAdminAuditLog();
    });
  }

  if (els.ratingSubmitBtn) {
    els.ratingSubmitBtn.addEventListener('click', () => {
      void handleRatingSubmit();
    });
  }

  if (els.authPassword) {
    els.authPassword.addEventListener('keydown', (ev) => {
      if (ev && ev.key === 'Enter') {
        ev.preventDefault();
        void handleAuthPrimary();
      }
    });
  }

  if (els.authConfirmPassword) {
    els.authConfirmPassword.addEventListener('keydown', (ev) => {
      if (ev && ev.key === 'Enter') {
        ev.preventDefault();
        if (authMode === 'register') {
          void handleAuthPrimary();
        }
      }
    });
  }
}

async function bootSupabase() {
  supabaseClient = initSupabaseClient();

  if (!supabaseClient) {
    setPortalNote(
      els.authConfigStatus,
      'Supabase auth is disabled. Edit site-config.js with your Supabase URL and anon key.',
      'error',
    );
    if (els.authPrimaryBtn) els.authPrimaryBtn.disabled = true;
    if (els.authSwitchBtn) els.authSwitchBtn.disabled = true;
    if (els.authForgotBtn) els.authForgotBtn.disabled = true;
    if (els.ratingSubmitBtn) els.ratingSubmitBtn.disabled = true;
    if (els.adminAuditRefreshBtn) els.adminAuditRefreshBtn.disabled = true;
    setAdminAuditPlaceholder('Supabase is not configured. Audit log unavailable.');
    setUiStatus(els.adminAuditStatus, 'Configure Supabase to enable admin audit history.', 'muted');
    await loadRatings();
    return;
  }

  setPortalNote(els.authConfigStatus, `Supabase ready for ${siteConfig.appName}.`, 'ok');
  if (els.adminAuditRefreshBtn) els.adminAuditRefreshBtn.disabled = false;

  const { data } = await supabaseClient.auth.getSession();
  await syncSessionFromSupabase(data ? data.session : null);

  supabaseClient.auth.onAuthStateChange((_event, session) => {
    void syncSessionFromSupabase(session);
  });
}

async function boot() {
  setSiteUrl();
  bindEvents();
  renderAuthMode();
  renderSessionUi();
  refreshResolvedDownloadUrl();

  await Promise.all([
    loadReleaseMetrics(),
    loadTrackedClicks(),
  ]);

  await bootSupabase();
}

void boot();
