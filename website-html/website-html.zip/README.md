# SmartHub Static Website (HTML only)

This folder is a pure static website. No Laravel and no build step required.

## Files

- `index.html` (professional landing page)
- `styles.css` (responsive UI styling)
- `app.js` (download metrics + redirect logic + Supabase auth/admin/rating flows)
- `site-config.js` (local runtime config for Supabase URL + anon key)
- `site-config.example.js` (copy/reference template)
- `supabase/portal_auth_ratings.sql` (schema + RLS for auth role, settings, ratings, audit log)
- `email-confirmation/index.html` (kept for auth redirect route)
- `.nojekyll`

## Download Tracking + Redirect

When users click **Download for Windows**:

1. The site increments a public counter using CountAPI.
2. It resolves the latest GitHub release.
3. It redirects users to the newest Windows installer asset (fallback: release page).

Configured in `app.js`:

- `RELEASE_OWNER`
- `RELEASE_REPO`
- `TRACKING_NAMESPACE`
- `TRACKING_KEY`

## Supabase Auth + Roles + Ratings

This static portal now supports:

- Register/Login with Supabase Auth
- Admin-only download link management
- Admin badge in top navigation
- Admin audit log for download-link changes
- User ratings tied to Supabase accounts

### 1) Configure Supabase in the website

Edit `site-config.js`:

```js
window.SMARTHUB_SITE_CONFIG = {
	supabaseUrl: 'https://YOUR_PROJECT_REF.supabase.co',
	supabaseAnonKey: 'YOUR_SUPABASE_ANON_KEY',
	emailRedirectTo: 'https://YOUR_DOMAIN/email-confirmation/',
	appName: 'SmartHub Portal',
};
```

Notes:

- `supabaseAnonKey` is the public key, safe for browser use.
- Never put service-role keys in this static website.

### 2) Create DB schema + RLS policies

In Supabase SQL Editor, run:

- `supabase/portal_auth_ratings.sql`

This creates:

- `portal_profiles` (stores role: user/admin)
- `portal_settings` (stores `windows_download_url`)
- `portal_ratings` (one rating per authenticated user)
- `portal_download_audit` (tracks who changed download URL and when)
- RLS policies for public read + restricted writes

### 3) Promote first admin

After signing up once via the website, set your account as admin in Supabase SQL Editor:

```sql
update public.portal_profiles
set role = 'admin'
where user_id = 'YOUR_AUTH_USER_UUID';
```

How to get your `user_id`:

- Supabase Dashboard -> Authentication -> Users

### 4) Configure auth redirect URLs

In Supabase Dashboard:

- Authentication -> URL Configuration
- Set Site URL to your production domain
- Add redirect URL:
	- `https://<YOUR_DOMAIN>/email-confirmation/`

Keep `site-config.js` `emailRedirectTo` exactly matched with this path.

## Deploy to Cloudflare Pages

- Project type: Pages
- Connect repository: `systempurpose/SmartHub3`
- Production branch: `main`
- Root directory: `website-html` (important when deploying from the full SmartHub repo)
- Build command: `exit 0`
- Build output directory: `.`

No build step is needed for this website.

## GitHub + Cloudflare Ready Flow

1. Push `website-html` changes to your GitHub repository.
2. Deploy folder to Cloudflare Pages.
3. Confirm `site-config.js` has production Supabase values.
4. Open deployed site and test:
	- Register
	- Login
	- Admin save download URL
	- Admin audit log entries update after each save/reset
	- User submit rating

## Supabase Redirect URL

Email confirmation route:

- `https://<YOUR_DOMAIN>/email-confirmation/`

Use this same URL in:

- Supabase Auth redirect settings
- `site-config.js` as `emailRedirectTo`
