package com.smarthub.diagnostics

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.text.format.Formatter
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val summaryView: TextView = findViewById(R.id.diagnostics_summary)
        val detailView: TextView = findViewById(R.id.diagnostics_detail)
        val exportButton: Button = findViewById(R.id.btn_export_json)

        val summary = buildSummary()
        val details = buildDetails()

        summaryView.text = summary
        detailView.text = details

        exportButton.setOnClickListener {
            exportJsonReport()
        }
    }

    private fun exportJsonReport() {
        val json = buildJsonReport()
        val jsonString = json.toString(2)

        // Save to a well-known file so the desktop companion can pull it via ADB if needed.
        val dir = getExternalFilesDir(null) ?: filesDir
        val outFile = File(dir, "smarthub_diagnostics.json")
        try {
            outFile.writeText(jsonString, Charsets.UTF_8)
            Toast.makeText(this, "JSON report saved to ${outFile.absolutePath}", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Failed to save JSON: ${e.message}", Toast.LENGTH_LONG).show()
        }

        // Also offer a share intent so the technician can send the report if desired.
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "application/json"
            putExtra(Intent.EXTRA_SUBJECT, "SmartHub diagnostics report")
            putExtra(Intent.EXTRA_TEXT, jsonString)
        }

        try {
            startActivity(Intent.createChooser(shareIntent, "Share diagnostics JSON"))
        } catch (_: Exception) {
            // If there is no activity to handle sharing, we silently ignore; the file is still saved locally.
        }
    }

    private fun buildSummary(): String {
        val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)

        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)
        val totalRam = readableBytes(memInfo.totalMem)

        val internal = Environment.getDataDirectory()
        val internalStats = android.os.StatFs(internal.path)
        val totalBytes = internalStats.blockSizeLong * internalStats.blockCountLong
        val freeBytes = internalStats.blockSizeLong * internalStats.availableBlocksLong

        val totalStorage = readableBytes(totalBytes)
        val freeStorage = readableBytes(freeBytes)

        return "Battery $level% · RAM $totalRam · Storage $freeStorage / $totalStorage"
    }

    private fun buildDetails(): String {
        val sb = StringBuilder()

        // Battery
        val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val voltage = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_VOLTAGE)
        val currentNow = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)

        sb.appendLine("BATTERY")
        sb.appendLine("  Level: $level%")
        if (voltage > 0) sb.appendLine("  Voltage: ${voltage} mV")
        if (currentNow != Int.MIN_VALUE) sb.appendLine("  Current now: ${currentNow} µA (sign/device dependent)")
        sb.appendLine()

        // Memory
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)
        sb.appendLine("MEMORY")
        sb.appendLine("  Total RAM: ${readableBytes(memInfo.totalMem)}")
        sb.appendLine("  Available: ${readableBytes(memInfo.availMem)}")
        sb.appendLine("  Low memory?: ${memInfo.lowMemory}")
        sb.appendLine()

        // Storage
        sb.appendLine("STORAGE (internal data)")
        val internal = Environment.getDataDirectory()
        appendStorageStats(sb, "  /data", internal)
        sb.appendLine()

        // OS / Build
        sb.appendLine("OS / BUILD")
        sb.appendLine("  Android: ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})")
        sb.appendLine("  Device: ${Build.MANUFACTURER} ${Build.MODEL}")
        sb.appendLine("  Fingerprint: ${Build.FINGERPRINT}")
        sb.appendLine()

        // Sensors (high-level only: which main types are present)
        val sensorSummary = SensorSummary(this)
        sb.appendLine("SENSORS")
        sb.appendLine("  Accelerometer: ${sensorSummary.hasAccelerometer}")
        sb.appendLine("  Gyroscope: ${sensorSummary.hasGyroscope}")
        sb.appendLine("  Proximity: ${sensorSummary.hasProximity}")
        sb.appendLine("  Light: ${sensorSummary.hasLight}")

        return sb.toString().trimEnd()
    }

    private fun buildJsonReport(): JSONObject {
        val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val voltage = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_VOLTAGE)
        val currentNow = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)

        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)

        val internal = Environment.getDataDirectory()
        val stat = android.os.StatFs(internal.path)
        val totalBytes = stat.blockSizeLong * stat.blockCountLong
        val freeBytes = stat.blockSizeLong * stat.availableBlocksLong
        val usedBytes = totalBytes - freeBytes

        val sensorSummary = SensorSummary(this)

        val batteryJson = JSONObject().apply {
            put("levelPercent", level)
            if (voltage > 0) put("voltageMv", voltage)
            if (currentNow != Int.MIN_VALUE) put("currentMicroAmp", currentNow)
        }

        val memoryJson = JSONObject().apply {
            put("totalBytes", memInfo.totalMem)
            put("availableBytes", memInfo.availMem)
            put("lowMemory", memInfo.lowMemory)
        }

        val storageJson = JSONObject().apply {
            put("path", internal.path)
            put("totalBytes", totalBytes)
            put("usedBytes", usedBytes)
            put("freeBytes", freeBytes)
        }

        val osJson = JSONObject().apply {
            put("androidVersion", Build.VERSION.RELEASE)
            put("sdkInt", Build.VERSION.SDK_INT)
            put("manufacturer", Build.MANUFACTURER)
            put("model", Build.MODEL)
            put("fingerprint", Build.FINGERPRINT)
        }

        val sensorsJson = JSONObject().apply {
            put("hasAccelerometer", sensorSummary.hasAccelerometer)
            put("hasGyroscope", sensorSummary.hasGyroscope)
            put("hasProximity", sensorSummary.hasProximity)
            put("hasLight", sensorSummary.hasLight)
        }

        return JSONObject().apply {
            put("summary", buildSummary())
            put("battery", batteryJson)
            put("memory", memoryJson)
            put("storage", storageJson)
            put("os", osJson)
            put("sensors", sensorsJson)
            put("generatedAt", System.currentTimeMillis())
        }
    }

    private fun appendStorageStats(sb: StringBuilder, label: String, dir: File) {
        try {
            val stat = android.os.StatFs(dir.path)
            val total = stat.blockSizeLong * stat.blockCountLong
            val free = stat.blockSizeLong * stat.availableBlocksLong
            val used = total - free
            sb.appendLine("$label → total ${readableBytes(total)}, used ${readableBytes(used)}, free ${readableBytes(free)}")
        } catch (e: Exception) {
            sb.appendLine("$label → error reading stats: ${e.message}")
        }
    }

    private fun readableBytes(bytes: Long): String = Formatter.formatFileSize(this, bytes)
}

class SensorSummary(context: Context) {
    val hasAccelerometer: Boolean
    val hasGyroscope: Boolean
    val hasProximity: Boolean
    val hasLight: Boolean

    init {
        val sm = context.getSystemService(Context.SENSOR_SERVICE) as android.hardware.SensorManager
        val list = sm.getSensorList(android.hardware.Sensor.TYPE_ALL)
        hasAccelerometer = list.any { it.type == android.hardware.Sensor.TYPE_ACCELEROMETER }
        hasGyroscope = list.any { it.type == android.hardware.Sensor.TYPE_GYROSCOPE }
        hasProximity = list.any { it.type == android.hardware.Sensor.TYPE_PROXIMITY }
        hasLight = list.any { it.type == android.hardware.Sensor.TYPE_LIGHT }
    }
}
