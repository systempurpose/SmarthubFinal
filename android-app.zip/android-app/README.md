# SmartHub Mobile Diagnostics App

This is a minimal Android companion app intended to run **entirely on the device** and expose truthful, offline diagnostics that complement the desktop SmartHub tool.

- No cloud calls, no analytics.
- Reads system information only through public Android APIs.
- Shows a clear summary (battery, storage, memory, sensors, OS/build info) on the phone screen.

## What it checks (on device)

- **Battery** – level, voltage and instantaneous current (when available).
- **Memory (RAM)** – total and available RAM, low-memory flag.
- **Storage** – internal `/data` total/used/free.
- **OS / Build** – Android version, manufacturer/model, build fingerprint.
- **Sensors** – presence of accelerometer, gyroscope, proximity and light sensors.

Because it uses standard Android APIs, it does *not* require root and does not read private app data or full system logs. Results are local to the phone screen.

## How to build and install

1. Open the `android-app` folder in **Android Studio** ("Import project" / "Open").
2. Let Gradle sync.
3. Connect the test phone (USB debugging on) or start an emulator.
4. Use **Run ▶** in Android Studio to install and launch *SmartHub Mobile Diagnostics* on the device.

Once installed, you can also use the desktop SmartHub "Install mobile app" button (ADB install) to push updated APKs to connected phones.
