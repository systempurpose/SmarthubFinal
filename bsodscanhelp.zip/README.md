# SmartHub BSOD Scan Help (USB-only)

This folder is a **single place** for the "Blue / Blank Screen" (no-ADB) diagnostic plan, response schema, scoring rules, and technician UI copy.

## What’s in here

- `bsdscanhelp.txt` — practical help text + implementation plan.
- `planforBSoD.txt` — original longer plan draft.
- `schemas/connection-check-v2.json` — documented response shape for `/connection-check`.
- `scoring.md` — explainable rules for mapping signals to Part 1 categories.
- `test-matrix.md` — scenarios you can validate on real devices.
- `ui-copy.md` — wording for the technician UI (no security-bypass claims).

## How to use it (in the SmartHub app)

1. Connect the phone to the PC with a **known-good data cable**.
2. In SmartHub UI, open the **Diagnose without USB debugging** flow.
3. Let it run (the deeper check samples USB state over time).
4. Read:
   - ADB visibility
   - Fastboot visibility
   - MTP/Portable visibility (Windows)
   - “Most likely reasons (Part 1)” + confidence

### What “Part 1” means
The tool classifies into these shop-facing buckets:
- System Errors
- Application Conflicts
- Hardware Malfunction
- Overheating
- Insufficient Storage

USB-only cannot always prove the last 3 with high confidence; the UI should show conservative confidence and clear next steps.

## How to run the backend (dev)

From the repo root:
- `npm run dev`

If you run the compiled build:
- `npm run build`
- `node dist/server.js`

### If the backend fails to start with EADDRINUSE
That means **port 3333 is already in use** (another SmartHub backend instance is still running).
Stop the old instance, or close the SmartHub desktop app, then retry.

## Useful endpoints (for debugging)

- `GET http://localhost:3333/connection-check?deep=1&samples=30&delayMs=1500`
  - Returns ADB/Fastboot/MTP/USB-transport info plus `bsodAnalysis`.
  - The Part 1 classification is in `bsodAnalysis.part1`.

- `GET http://localhost:3333/screen-visual-check?samples=30&delayMs=500`
  - Optional camera-based analysis (no ADB required).

## Implementation pointers (where the code lives)

- Backend triage: `src/routes/noDebugRoutes.ts` (active `/connection-check` route used by the app)
- UI rendering: `js/ui.js` (`openNoDebugModal()` + `openQuickNoDebugModal()`)
- Optional camera helper: `bsod-diagnostic/phone_screen_diag.py`
